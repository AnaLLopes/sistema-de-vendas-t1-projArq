package com.bcopstein.sistvendas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistVendasApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistVendasApplication.class, args);
	}

}
