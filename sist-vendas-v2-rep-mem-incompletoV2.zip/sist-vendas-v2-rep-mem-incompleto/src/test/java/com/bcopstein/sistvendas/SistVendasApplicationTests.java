package com.bcopstein.sistvendas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistVendasApplicationTests {

	@Test
	void contextLoads() {
	}

}
