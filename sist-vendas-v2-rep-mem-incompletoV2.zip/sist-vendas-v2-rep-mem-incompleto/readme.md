#Versão incompleta
Nesta versão o caso de uso "Efetiva Orcamento" não esta implementado e deve ser completado

- Execute o sistema
- Teste os endpoints:
    - Listar produtos
    - Criar orçamento
- Implemente o caso de uso "Efetiva Orçamento"
- Teste a versão final dos sistema